import React, {useState} from 'react';

export default function App(){
  const [audio,setAudio]=useState(null), [images,setImages]=useState([]), [busy,setBusy]=useState(false), [msg,setMsg]=useState(''), [video,setVideo]=useState('');
  const submit=async()=>{
    if(!audio){setMsg('আগে ভয়েসওভার MP3 বা WAV ফাইল দাও।');return;}
    if(!images.length){setMsg('কমপক্ষে একটি ছবি বা PNG দাও।');return;}
    setBusy(true);setMsg('ফাইল আপলোড হচ্ছে এবং ভিডিও তৈরি হচ্ছে…');setVideo('');
    try{
      const fd=new FormData();fd.append('audio',audio);images.forEach(f=>fd.append('images',f));
      fd.append('fps','60');fd.append('width','1080');fd.append('height','1920');
      const r=await fetch('/api/render',{method:'POST',body:fd});
      const data=await r.json();if(!r.ok)throw new Error(data.error||'ভিডিও তৈরি করা যায়নি');
      setVideo(data.videoUrl);setMsg('ভিডিও তৈরি হয়েছে। নিচে দেখে MP4 ডাউনলোড করো।');
    }catch(e){setMsg(e.message+' — সার্ভার চালু আছে কি না এবং ফাইলের ধরন ঠিক আছে কি না দেখো।');}
    finally{setBusy(false);}
  };
  return <main>
    <header><div className="brand">VW</div><div><h1>VitalWealth Studio</h1><p>Voiceover থেকে Cinematic Documentary Video</p></div></header>
    <section className="hero"><span className="tag">AUTO VIDEO MAKER</span><h2>তুমি ভয়েস দাও।<br/>ভিডিও সাজানোর কাজ অ্যাপ করবে।</h2><p>ভয়েসওভার ও PNG/ছবি আপলোড করো। সার্ভার ছবিগুলো দিয়ে 9:16 ভিডিও বানাবে।</p></section>
    <section className="panel">
      <label>১. ভয়েসওভার আপলোড <small>MP3 / WAV</small></label>
      <input type="file" accept="audio/mpeg,audio/wav,audio/*" onChange={e=>setAudio(e.target.files?.[0]||null)}/>
      {audio&&<p className="picked">✓ {audio.name}</p>}
      <label>২. দৃশ্যের ছবি / Transparent PNG <small>একাধিক ছবি দেওয়া যাবে</small></label>
      <input type="file" accept="image/png,image/jpeg,image/webp" multiple onChange={e=>setImages(Array.from(e.target.files||[]))}/>
      {images.length>0&&<p className="picked">✓ {images.length}টি ছবি নির্বাচন করা হয়েছে</p>}
      <div className="settings"><div><b>9:16</b><span>Vertical</span></div><div><b>1080×1920</b><span>Resolution</span></div><div><b>60 FPS</b><span>Frame rate</span></div></div>
      <button onClick={submit} disabled={busy}>{busy?'ভিডিও তৈরি হচ্ছে…':'ভিডিও তৈরি করো'}</button>
      {msg&&<p className="message">{msg}</p>}
    </section>
    {video&&<section className="panel"><h3>তোমার ভিডিও তৈরি</h3><video controls playsInline src={video}/><a className="download" href={video} download>MP4 ডাউনলোড</a></section>}
    <footer>Remotion Render Engine · MP4 / H.264 · Cinematic motion</footer>
  </main>
}
import React from 'react';
import {registerRoot,Composition} from 'remotion';
import {AutoDocumentary} from './video.jsx';
const Root=()=> <Composition id="AutoDocumentary" component={AutoDocumentary} durationInFrames={1800} fps={60} width={1080} height={1920} defaultProps={{audioPath:'',images:[],durationInFrames:1800}} />;
registerRoot(Root);
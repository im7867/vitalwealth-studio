import React from 'react';
import {AbsoluteFill,Audio,Img,Sequence,interpolate,useCurrentFrame,useVideoConfig,staticFile} from 'remotion';

const Shot=({src,index,total})=>{
 const frame=useCurrentFrame();const {durationInFrames}=useVideoConfig();
 const progress=interpolate(frame,[0,durationInFrames],[0,1],{extrapolateRight:'clamp'});
 const zoom=1.04+0.12*progress;
 const direction=index%2===0?1:-1;
 return <AbsoluteFill style={{background:'#090d14',overflow:'hidden'}}>
  <Img src={staticFile(src)} style={{width:'100%',height:'100%',objectFit:'cover',transform:`scale(${zoom}) translateX(${direction*progress*2}%)`}}/>
  <AbsoluteFill style={{background:'linear-gradient(180deg,rgba(0,0,0,.08),rgba(0,0,0,.18) 55%,rgba(0,0,0,.5))'}}/>
 </AbsoluteFill>
};
export const AutoDocumentary=({audioPath,images,durationInFrames})=>{
 const {fps}=useVideoConfig();const count=Math.max(1,images.length);const each=Math.ceil(durationInFrames/count);
 return <AbsoluteFill style={{background:'#000'}}>
  {images.map((src,i)=><Sequence key={`${src}-${i}`} from={i*each} durationInFrames={Math.max(1,Math.min(each,durationInFrames-i*each))}>
    <Shot src={src} index={i} total={count}/>
  </Sequence>)}
  {audioPath?<Audio src={staticFile(audioPath)}/>:null}
 </AbsoluteFill>
};
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './ui.jsx';
import './style.css';
createRoot(document.getElementById('root')).render(<App />);
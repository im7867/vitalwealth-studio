# VitalWealth Studio — Auto Video Starter

Mobile-first upload page + Express render API + Remotion renderer.

## What works in this starter
- Upload one MP3/WAV voiceover and multiple PNG/JPG/WEBP images.
- Reads audio duration on the server.
- Builds a vertical 1080x1920, 60 FPS H.264 MP4 with Remotion.
- Sequences uploaded images across the voiceover and adds gentle motion.
- Returns an MP4 preview/download URL.

## Important limits
This is a working starter pipeline, not a complete AI editor. It does **not** yet transcribe narration, understand the story, generate missing images, create true 2.5D depth layers, or choose story-specific scenes. It evenly distributes uploaded images over the audio. Those features need speech-to-text, an AI planning service, image-generation API, and additional render logic. Do not put API keys in the browser.

## Run locally
Requires Node.js 20+ and system Chromium/FFmpeg.
```bash
npm install
npm run dev
```
Open the Vite address shown in the terminal. The API runs on port 8787.

## Deploy
Deploy as a Docker web service on a host that supports Chromium and FFmpeg. The service needs writable persistent storage for `storage/`. Set `PORT` if the host requires it. For production, add authentication, upload quotas, job queueing, cleanup, and persistent object storage before public use.

## Important
Remotion rendering happens on the server, not on the Android phone. The phone only uploads files and views the result. Cloud hosting and any AI APIs may have usage charges.

import express from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {parseFile} from 'music-metadata';
import {bundle} from '@remotion/bundler';
import {getCompositions, renderMedia} from '@remotion/renderer';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(__dirname,'..');
const uploads=path.join(root,'storage','uploads');
const renders=path.join(root,'storage','renders');
const renderAssets=path.join(root,'public','render-assets');
fs.mkdirSync(uploads,{recursive:true});fs.mkdirSync(renders,{recursive:true});fs.mkdirSync(renderAssets,{recursive:true});
const app=express();
const storage=multer.diskStorage({destination:(_,__,cb)=>cb(null,uploads),filename:(_,file,cb)=>cb(null,`${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase()}`)});
const upload=multer({storage,limits:{fileSize:150*1024*1024}});
let serveUrlPromise;
app.use('/renders',express.static(renders));
app.use(express.static(path.join(root,'dist')));
app.get('/api/health',(_,res)=>res.json({ok:true,engine:'Remotion'}));

app.post('/api/render',upload.fields([{name:'audio',maxCount:1},{name:'images',maxCount:40}]),async(req,res)=>{
  try{
    const audio=req.files?.audio?.[0];const images=req.files?.images||[];
    if(!audio||!images.length)return res.status(400).json({error:'একটি অডিও এবং অন্তত একটি ছবি প্রয়োজন।'});
    const meta=await parseFile(audio.path);const duration=meta.format.duration;
    if(!duration||!Number.isFinite(duration))throw new Error('অডিওর দৈর্ঘ্য পড়া যায়নি।');
    const fps=60,width=1080,height=1920,durationInFrames=Math.max(1,Math.ceil(duration*fps));
    const copyAsset=(file)=>{
      const safeName=`${Date.now()}-${path.basename(file.path)}`;
      fs.copyFileSync(file.path,path.join(renderAssets,safeName));
      return `render-assets/${safeName}`;
    };
    const props={audioPath:copyAsset(audio),images:images.map(copyAsset),durationInFrames};
    if(!serveUrlPromise)serveUrlPromise=bundle({entryPoint:path.join(root,'src','remotion-entry.jsx')});
    const serveUrl=await serveUrlPromise;
    const comps=await getCompositions(serveUrl,{inputProps:props});
    const comp=comps.find(c=>c.id==='AutoDocumentary');
    if(!comp)throw new Error('Remotion composition পাওয়া যায়নি।');
    const output=path.join(renders,`vitalwealth-${Date.now()}.mp4`);
    await renderMedia({composition:{...comp,durationInFrames,width,height,fps},serveUrl,codec:'h264',outputLocation:output,inputProps:props,concurrency:2});
    res.json({ok:true,videoUrl:`/renders/${path.basename(output)}`,durationSeconds:duration});
  }catch(e){console.error(e);res.status(500).json({error:e.message||'Render failed'});}
});

const port=process.env.PORT||8787;
app.listen(port,'0.0.0.0',()=>console.log(`VitalWealth render server listening on ${port}`));